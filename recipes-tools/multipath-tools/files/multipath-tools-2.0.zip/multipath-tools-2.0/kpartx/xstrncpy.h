extern void xstrncpy(char *dest, const char *src, size_t n);
