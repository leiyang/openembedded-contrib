#ifndef _READSECTOR0_H
#define _READSECTOR0_H

int readsector0 (struct checker *);
int readsector0_init (struct checker *);
void readsector0_free (struct checker *);

#endif /* _READSECTOR0_H */
