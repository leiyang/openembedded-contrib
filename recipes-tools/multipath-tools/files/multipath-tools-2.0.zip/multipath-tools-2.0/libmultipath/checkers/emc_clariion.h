#ifndef _EMC_CLARIION_H
#define _EMC_CLARIION_H

int emc_clariion (struct checker *);
int emc_clariion_init (struct checker *);
void emc_clariion_free (struct checker *);

#endif /* _EMC_CLARIION_H */
