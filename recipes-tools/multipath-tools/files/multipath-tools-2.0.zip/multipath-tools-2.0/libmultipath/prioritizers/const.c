#include <stdio.h>

#include <prio.h>

int getprio (struct path * pp, char * args)
{
	return 1;
}
